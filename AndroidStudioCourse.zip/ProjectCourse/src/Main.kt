import kotlin.math.pow
import kotlin.math.sqrt

fun main(args: Array<String>){
    val tringle = Tringle(
        Point(0.0, 0.0),
        Point(0.0, 3.0),
        Point(4.0, 0.0)
    )

    tringle.print()
    println("Perimeter is ${tringle.getPerimeter()}")
    println("Area is ${tringle.getArea()}")
    tringle.setPoints(
        Point(0.0, 0.0),
        Point(0.0, 3.0),
        Point(0.0, 4.0)
    )
}

fun isCollin(p1: Point, p2: Point, p3: Point): Boolean{
    //(x1 - x2)(y2 - y3) + (x2 - x3)(y3 - y1) + (x3 - x1)(y1 - y2) = 0
    return (p1.x - p2.x)*(p2.y - p3.y) + (p2.x - p3.x)*(p3.y - p1.y) + (p3.x - p1.x)*(p1.y - p2.y) == 0.0
}

class Point(var x : Double, var y : Double)

class Tringle(var p1 : Point, var p2 : Point, var p3 : Point){
    var a: Double = 0.0
    var b: Double = 0.0
    var c: Double = 0.0

    init {
        if(isCollin(p1, p2, p3)){
            throw IllegalArgumentException("Points should not be collinear")
        }
        a = sqrt((p1.x - p2.x).pow(2) + (p1.y - p2.y).pow(2))
        b = sqrt((p2.x - p3.x).pow(2) + (p2.y - p3.y).pow(2))
        c = sqrt((p1.x - p3.x).pow(2) + (p1.y - p3.y).pow(2))
    }

    fun print(){
        println("First point: x: ${p1.x}, y: ${p1.y}")
        println("Second point: x: ${p2.x}, y: ${p2.y}")
        println("Third point: x: ${p3.x}, y: ${p3.y}")
        println("Sides: $a, $b, $c")
    }

    fun getPerimeter(): Double {
        return a + b + c
    }

    fun getArea(): Double {
        val p : Double = (a + b + c) / 2.0
        return sqrt(p * (p - a) * (p - b) * (p - c))
    }

    fun setPoints(_p1: Point, _p2: Point, _p3: Point){
        if(isCollin(_p1, _p2, _p3)){
            throw IllegalArgumentException("Points should not be collinear")
        }
        else {
            p1 = _p1
            p2 = _p2
            p3 = _p3
        }
    }
}